import java.util.Scanner;

public class CasinoWarGame implements Playable {
    private Deck deck;
    private Player player;
    private Scanner input;

    public CasinoWarGame() {
        deck = new Deck();
        player = new Player(100.0);
        input = new Scanner(System.in);
    }

    public void playRound() {
        System.out.println("Balance: $" + player.getBalance());
        System.out.print("Enter wager: ");
        double wager = input.nextDouble();

        if (wager > player.getBalance()) {
            System.out.println("Invalid wager.");
            return;
        }

        Card playerCard = deck.deal();
        Card dealerCard = deck.deal();

        System.out.println("Player card: " + playerCard);
        System.out.println("Dealer card: " + dealerCard);

        if (playerCard.getValue() > dealerCard.getValue()) {
            player.win(wager);
            System.out.println("You win!");
        } else if (playerCard.getValue() < dealerCard.getValue()) {
            player.lose(wager);
            System.out.println("You lose!");
        } else {
            System.out.println("War! Tie round.");
        }
    }

    public static void main(String[] args) {
        CasinoWarGame game = new CasinoWarGame();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("1. Play Round");
            System.out.println("2. Exit");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> game.playRound();
                case 2 -> System.out.println("Goodbye!");
                default -> System.out.println("Invalid option.");
            }
        } while (choice != 2);
    }
}