public interface Playable {
    void playRound();
}