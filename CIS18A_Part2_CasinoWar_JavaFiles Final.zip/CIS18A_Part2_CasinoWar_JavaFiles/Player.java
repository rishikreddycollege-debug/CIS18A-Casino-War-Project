public class Player {
    private double balance;

    public Player(double balance) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void win(double amount) {
        balance += amount;
    }

    public void lose(double amount) {
        balance -= amount;
    }
}