import java.util.Random;

public class Deck extends Card implements Shufflable {
    private Card[] cards;
    private int index;

    public Deck() {
        super(0, "");
        cards = new Card[52];
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        int k = 0;
        for (String s : suits) {
            for (int v = 2; v <= 14; v++) {
                cards[k++] = new Card(v, s);
            }
        }
        shuffle();
    }

    public void shuffle() {
        Random r = new Random();
        for (int i = 0; i < cards.length; i++) {
            int j = r.nextInt(cards.length);
            Card temp = cards[i];
            cards[i] = cards[j];
            cards[j] = temp;
        }
        index = 0;
    }

    public Card deal() {
        if (index >= cards.length) shuffle();
        return cards[index++];
    }
}