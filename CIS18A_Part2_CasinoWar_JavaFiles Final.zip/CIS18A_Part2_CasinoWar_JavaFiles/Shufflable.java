public interface Shufflable {
    void shuffle();
}